

function openNav() {
    document.getElementById("mySidenav").style.width = "1270px";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0px";
  }